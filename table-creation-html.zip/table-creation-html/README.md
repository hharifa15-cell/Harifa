# Table creation. HTML

A Pen created on CodePen.

Original URL: [https://codepen.io/Harifa-Harifa/pen/ZYbOxOa](https://codepen.io/Harifa-Harifa/pen/ZYbOxOa).


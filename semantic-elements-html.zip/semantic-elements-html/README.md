# Semantic Elements. Html

A Pen created on CodePen.

Original URL: [https://codepen.io/Harifa-Harifa/pen/GgpEPgG](https://codepen.io/Harifa-Harifa/pen/GgpEPgG).


# Student information. Html

A Pen created on CodePen.

Original URL: [https://codepen.io/Harifa-Harifa/pen/JoYxbMW](https://codepen.io/Harifa-Harifa/pen/JoYxbMW).


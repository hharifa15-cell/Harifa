# Css selector. Html

A Pen created on CodePen.

Original URL: [https://codepen.io/Harifa-Harifa/pen/JoYrJzd](https://codepen.io/Harifa-Harifa/pen/JoYrJzd).


# Css box model. Html

A Pen created on CodePen.

Original URL: [https://codepen.io/Harifa-Harifa/pen/raOGzaX](https://codepen.io/Harifa-Harifa/pen/raOGzaX).


# Registration form. Html

A Pen created on CodePen.

Original URL: [https://codepen.io/Harifa-Harifa/pen/GgpzNdB](https://codepen.io/Harifa-Harifa/pen/GgpzNdB).

